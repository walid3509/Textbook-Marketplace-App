package mobile.app.finalproject;

public class User {

    public String username, email;

    public User (){

    }

    public User (String username, String email){
        this.username = username;
        this.email = email;
    }

}
