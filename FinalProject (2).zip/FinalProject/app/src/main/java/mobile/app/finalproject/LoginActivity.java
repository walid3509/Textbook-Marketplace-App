package mobile.app.finalproject;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Patterns;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ProgressBar;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;

public class LoginActivity extends AppCompatActivity {


    private ImageButton goHome;
    private Button gotoRegisterButton, loginButton;
    private EditText emailLogin, passwordLogin;

    private FirebaseAuth mAuth;
    private ProgressBar progressBar_;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        gotoRegisterButton = findViewById(R.id.gotoRegisterButton);
        goHome = findViewById(R.id.goHome);
        loginButton = findViewById(R.id.loginButton);
        emailLogin = findViewById(R.id.usernameLogin);
        passwordLogin = findViewById(R.id.passwordLogin);
        progressBar_ = findViewById(R.id.progressBarLogin);

        mAuth = FirebaseAuth.getInstance();

        goHome.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                openMainActivity();
            }
        });

        gotoRegisterButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                openRegisterActivity();}
        });

        loginButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                userLogin();
            }
        });
    }



    public void openRegisterActivity() {
        Intent intent = new Intent(this, RegisterActivity.class);
        startActivity(intent);
    }

    public void openMainActivity(){
        Intent intent = new Intent(this, MainActivity.class);
        startActivity(intent);
    }

    private void userLogin(){
        String email = emailLogin.getText().toString().trim();
        String password = passwordLogin.getText().toString().trim();

        if (email.isEmpty()){
            emailLogin.setError("Email is required!");
            emailLogin.requestFocus();
        }
        if (!Patterns.EMAIL_ADDRESS.matcher(email).matches()){
            emailLogin.setError("Valid Email is required!");
            emailLogin.requestFocus();
        }
        if (password.isEmpty()){
            passwordLogin.setError("Password is Required");
            passwordLogin.requestFocus();
        }
        if (password.length() < 6){
            passwordLogin.setError("Password longer the 6 characters is required");
            passwordLogin.requestFocus();
        }

        progressBar_.setVisibility(View.VISIBLE);

        mAuth.signInWithEmailAndPassword(email, password).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
            @Override
            public void onComplete(@NonNull Task<AuthResult> task) {

                if (task.isSuccessful()){

                    startActivity(new Intent(LoginActivity.this, ProfileActivity.class));

                }else {
                    Toast.makeText(LoginActivity.this, "Faild to login! Username or password did not match", Toast.LENGTH_LONG).show();
                }
            }
        });
    }

}