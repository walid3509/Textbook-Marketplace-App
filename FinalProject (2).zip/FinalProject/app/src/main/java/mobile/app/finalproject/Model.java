package mobile.app.finalproject;

public class Model {
    String title, contributors, isbn, price;

    public String getTitle() {
        return title;
    }

    public String getContributors() {
        return contributors;
    }

    public String getIsbn() {
        return isbn;
    }

    public String getPrice() {
        return price;
    }
}
