package mobile.app.finalproject;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Patterns;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ProgressBar;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.FirebaseDatabase;

public class RegisterActivity extends AppCompatActivity {

    private EditText emailRegister, passwordRegister, rePasswordRegister, userNameRegister;
    private Button registerSubmit;
    private ImageButton goHomeRegister;
    private ProgressBar progressBar;
    private FirebaseAuth mAuth;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        mAuth = FirebaseAuth.getInstance();

        emailRegister = findViewById(R.id.emailRegister);
        passwordRegister = findViewById(R.id.passwordRegister);
        rePasswordRegister = findViewById(R.id.rePasswordRegister);
        userNameRegister = findViewById(R.id.userNameRegister);
        registerSubmit = findViewById(R.id.registerSubmit);
        goHomeRegister = findViewById(R.id.goHomeRegister);
        progressBar = findViewById(R.id.progressBarRegister);

        registerSubmit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                registerUser();
            }
        });

        goHomeRegister.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                openMainActivity();
            }
        });
    }

    public void openMainActivity(){
        Intent intent = new Intent(this, MainActivity.class);
        startActivity(intent);
    }

    private void registerUser(){
        String email = emailRegister.getText().toString().trim();
        String password = passwordRegister.getText().toString().trim();
        String rePassword = rePasswordRegister.getText().toString().trim();
        String username = userNameRegister.getText().toString().trim();

        if (username.isEmpty()){
            userNameRegister.setError("Username is required!");
            userNameRegister.requestFocus();
        }
        if (email.isEmpty()){
            emailRegister.setError("Email is required!");
            emailRegister.requestFocus();
        }
        if (!Patterns.EMAIL_ADDRESS.matcher(email).matches()){
            emailRegister.setError("Valid Email is required!");
            emailRegister.requestFocus();
        }
        if (password.isEmpty()){
            passwordRegister.setError("Password is Required");
            passwordRegister.requestFocus();
        }
        if (password.length() < 6){
            passwordRegister.setError("Password longer the 6 characters is required");
            passwordRegister.requestFocus();
        }

        if (!password.equals(rePassword)){
            passwordRegister.setError("Passwords Do not match");
            passwordRegister.requestFocus();
        }
        progressBar.setVisibility(View.VISIBLE);
        mAuth.createUserWithEmailAndPassword(email, password)
                .addOnCompleteListener(new OnCompleteListener<AuthResult>() {
            @Override
            public void onComplete(@NonNull Task<AuthResult> task) {

                if (task.isSuccessful()){
                    User user = new User(username, email);
                    FirebaseDatabase.getInstance().getReference("Users")
                            .child(FirebaseAuth.getInstance().getCurrentUser().getUid())
                            .setValue(user).addOnCompleteListener(new OnCompleteListener<Void>() {
                                @Override
                                public void onComplete(@NonNull Task<Void> task) {

                                    if (task.isSuccessful()){
                                        Toast.makeText(RegisterActivity.this, "User has been successfully registered", Toast.LENGTH_LONG).show();
                                        startActivity(new Intent(RegisterActivity.this, ProfileActivity.class));


                                    } else {
                                        Toast.makeText(RegisterActivity.this, "User register Failed!", Toast.LENGTH_LONG).show();

                                    }
                                    progressBar.setVisibility(View.GONE);
                                }
                            });
                }

            }
        });
    }




}